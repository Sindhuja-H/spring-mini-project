package com.bankapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBankRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBankRestApplication.class, args);
	}

}
